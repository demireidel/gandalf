# VERSIONS

Exact declared versions:
- next: 15.5.2
- react: 19.1.1
- react-dom: 19.1.1
- typescript: 5.9.2
- tailwindcss: 4.1.12
- three: 0.179.1
- @react-three/fiber: 9.3.0
- @react-three/drei: 10.7.4
- three-stdlib: 2.36.0
- zustand: 4.5.7
- lucide-react: 0.542.0
- r3f-perf: 7.2.3
- postprocessing: 6.37.7
- @types/three: 0.179.0
- @playwright/test: 1.48.2
- @types/node: 22.7.8

Self-heal changes: none (initial scaffold).
